                     Readme File for Code Example:
               CE484 - Generating phase shifted PWMs using Output Compare modules and Peripheral trigger generator(PTG)
               --------------------------------------------------------------------------------------------------------

This file contains the following sections:
1. Code Example Description
2. Folder Contents
3. Suggested Development Resources
4. Reconfiguring the project for a different dsPIC33E device
5. Revision History


1. Code Example Description:
----------------------------
In this example, Timer 2 is setup to time-out every 40 microseconds (25Khz Rate). 
This is used as synchronisation source of Output Compare Module 1

Output Compare Module 1 is configured in Edge aligned PWM mode and Duty cycle is set for 5us(12.5% duty)
OC1 is clocked from Peripheral Clock .

PTG sequencer is set to wait for OC1 rising edge and then wait for half of the PWM period i.e 20us.
This is done by configuring PTG general purpose timer PTGTO.After the time out of 20 us ,the PTG will generate 
PTG Trigger Ouput1.And this is selects as synchronisation source of Output Compare 2 (OC2).Thus inserting 
phase shift of half the PWM period between OC1 and OC2 outputs.

PTG Timer is configured for delay of 20us and calculation is as follows:

Required delay: 20us
PTG Clock: 70MHz
COunt in PTGT0LIm: 20us/(1/70MHz) = 20us*70Mhz = 1400;

In this example OC2 is configured for 25% duty cycle or 10us .

And the OC1 and OC2 outputs are mapped to RP54,RP55 pin respectively.
                   

                   .                                                                                 .
                   .                                                                                 .
                   .<----------------------------------------------Period = 20us------------------- >.
                    __________                                                                        __________
                   |          |	                                                                     |          |
OC1(RP54) 	___|<--5us--> |______________________________________________________________________|          |_____________________________________
                   .                                         ____________________                                                              _______
                   .                                        |                    |          		                                      |
OC2(RP55)	____________________________________________|<-------10us------> |____________________________________________________________|
                   .                                        .                                                                                 .
                   .                                        .                                                                                 .
                   .<------Phase shift = 20us------------- >.<--------------------------------- Period = 40us--------------------------------->

This can be reconfigured according to application requirement.


2. Folder Contents:
-------------------
a. firmware
        This folder contains all the C, Assembler source files and  include files
	(*.c,*.s,*.h) used in demonstrating the described example. 
b. system_config
		This folder contains all the xxx_config.c file, which contain basic configuration routines and pin-remap code for a specific platform.
c. exp16/
		This folder contains various folders like dspic33ep512gm710, depending on the platform.Each platform can folder contain,configuration specific 
		source files.

3. Suggested Development Resources:
-----------------------------------
        a. Explorer 16 Demo board with dsPIC33EP512GM710 controller

4. Reconfiguring the project for a different dsPIC33E device:
-------------------------------------------------------------
The Project/Workspace can be easily reconfigured for  dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device.
Please use the following general guidelines:
        a. Change device selection within MPLAB� IDE to a dspic33ep512gm710/dspic33ep512mu810/dspic33ep256gp506 device of
        your choice by using the following menu option:
        MPLAB X>>Configuration drop-down option>><Listed Device Configuration>

        b. Re-build the MPLAB� project using the menu option:
        MPLAB X>>Build Main Project

        c. Download the hex file into the device and run.

5. Revision History :
---------------------
       Initial Release of the Code Example
	   01/31/2014 - Code Example updated to new format for dspic33ep512gm710
